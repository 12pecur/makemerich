# makemerich
## NOTICE!

I am not responsible for any money lost through this trading bot, you may trade at our own risk.
This trading bot does not acquire any sort of API key and does automatically submit orders.
There is no literal money being traded through the bot. The bot_rich variable is just a theoretical value if the bot traded with real money.

# installation: 

clone the repository: https://github.com/12pecur/makemerich.git

git branch -M main


# Requirements:

```bash
$ pip install colorama
$ pip install yfinance --upgrade --no-cache-dir
$ pip install -r requirements.txt
